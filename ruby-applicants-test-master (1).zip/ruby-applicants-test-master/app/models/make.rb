class Make < ActiveRecord::Base
end
